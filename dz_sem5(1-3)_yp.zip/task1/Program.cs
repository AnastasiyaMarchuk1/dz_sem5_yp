﻿//Напишите программу, которая на вход
//принимает позиции элемента в двумерном массиве, и
//возвращает значение этого элемента или же указание,
//что такого элемента нет.

int[,] CreateMatrixRndInt(int rows, int columns, int min, int max)
{
int[,] matrix = new int[rows, columns];
Random rnd = new Random();
for (int i = 0; i < rows; i++)   //rows=matrix.GetLength(0)
{
    for (int j = 0; j < columns; j++)   //columns=matrix.GetLength(1)
{
   matrix[i,j] = rnd.Next(min, max) ;
}
}
return matrix;
}


void PrintMatrix(int[,] matrix)
{
    for (int i = 0; i < matrix.GetLength(0); i++)
        {
             Console.Write("[");
             for (int j = 0; j <  matrix.GetLength(1); j++)
               {
                 Console.Write($"{matrix[i,j], 4}");
               }
             Console.WriteLine("]");
        }
}


void PrintElementOfMatrix(int[,] matrix, int i, int j) 
{
    if (i<matrix.GetLength(0) && j<matrix.GetLength(1) )
    {
        Console.WriteLine($"matrix[{i},{j}] = {matrix[i,j]}");
    }
    else
    {
        Console.WriteLine($"matrix[{i},{j}] ne sushchestvuet");
    } 
}

int[,] array2d=CreateMatrixRndInt(4, 7, 1, 20);
PrintMatrix(array2d);
PrintElementOfMatrix(array2d, 3,6) ;