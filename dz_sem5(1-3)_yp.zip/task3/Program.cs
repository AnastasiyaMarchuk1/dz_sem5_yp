﻿//Задайте прямоугольный двумерный массив.
//Напишите программу, которая будет находить строку с
//наименьшей суммой элементов.

int[,] CreateMatrixRndInt(int rows, int columns, int min, int max)
{
int[,] matrix = new int[rows, columns];
Random rnd = new Random();
for (int i = 0; i < rows; i++)   //rows=matrix.GetLength(0)
{
    for (int j = 0; j < columns; j++)   //columns=matrix.GetLength(1)
{
   matrix[i,j] = rnd.Next(min, max) ;
}
}
return matrix;
}

void PrintMatrix(int[,] matrix)
{
    for (int i = 0; i < matrix.GetLength(0); i++)
        {
             Console.Write("[");
             for (int j = 0; j <  matrix.GetLength(1); j++)
               {
                 Console.Write($"{matrix[i,j], 4}");
               }
             Console.WriteLine("]");
        }
}

void FindRowWithSmallestSum(int[,] matrix)
{   //creating an array of sums
    int[] array=new int[matrix.GetLength(0)];
    for (int i = 0; i <matrix.GetLength(0) ; i++)   //rows=matrix.GetLength(0)
{
    int sum=0;
    for (int j = 0; j < matrix.GetLength(1); j++)   //columns=matrix.GetLength(1)
{
   sum+=matrix[i,j];
}
array[i]=sum;
}
//

for (int i = 0; i < array.Length; i++)
{
    Console.Write(array[i]+", ");
}

int smallestsum=array[0];
int indexofrowwithsmallestsum=0;
for (int i = 1; i <matrix.GetLength(0) ; i++)   //rows=matrix.GetLength(0)
{
if (array[i]<smallestsum)
{
    smallestsum=array[i];
indexofrowwithsmallestsum=i;
}
}
Console.WriteLine($"   => {indexofrowwithsmallestsum} - stroka s naimenshey summoy");
}

int[,] array2d=CreateMatrixRndInt(4, 7, 1, 20);
PrintMatrix(array2d);
Console.WriteLine();
FindRowWithSmallestSum(array2d);